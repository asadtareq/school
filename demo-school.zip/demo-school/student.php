<?php
require_once 'inc/session.php';
require_once 'inc/db.php';
//require_once 'inc/user_fetch.php';
require_once 'inc/info.php';
//require_once 'inc/functions.php';

if (isset($_POST['add'])) {
  $not = mysqli_real_escape_string($connect,$_POST['not']);
  $c = mysqli_real_escape_string($connect,$_POST['c']);
  $r = mysqli_real_escape_string($connect,$_POST['r']);
  $teachersql="INSERT INTO sms_student_info(`name`,`class`,`roll`,`image`) VALUES('$not','$c','$r','s1.jpeg')";
  if ($connect->query($teachersql)) {
    echo "<script>alert('Success')</script>";
    echo "<script>window.location.href = 'student.php'</script>";
  }else{
    echo "<script>alert('Failed')</script>";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Basic Page Info -->
  <meta charset="utf-8">
  <title><?php echo $title;?></title>
  <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/d24c97ff8f.js" crossorigin="anonymous"></script>
  

  <!-- Global site tag (gtag.js) - Google Analytics -->
 
 
</head>
<body>
<!--Menu start-->
<?php require('inc/header.php'); ?>       

<div class="container"><br>
  <div class="card-header bg-secondary text-white">Add New Student</div>
  <div class="card">
    <div class="container">
      <form method="POST">
        <div class="form-group">
          <label>Name of Student</label>
          <input type="text" name="not" class="form-control">
        </div>
        <div class="form-group">
          <label>Class</label>
          <input type="number" name="c" class="form-control">
        </div><div class="form-group">
          <label>Roll</label>
          <input type="number" name="r" class="form-control">
        </div><br>
        <input type="submit" name="add" value='Add New' class='btn btn-success'>
      </form><br>
    </div>
  </div>
</div>


<div class="container"><br>
  <div class="card-header bg-secondary text-white">Students List</div>
  <div class="card">
    <div class="container">
      <table class='table table-hover table-bordered table-sm'>
        <tr>
          <th>SI</th>
          <th>Name</th>
          <th>Class</th>
          <th>Roll</th>
          <th>Action</th>
        </tr>
        <?php
          $sel_te_sql="SELECT * FROM sms_student_info ";
          $r1=$connect->query($sel_te_sql);
          $si=0;
          while($row=$r1->fetch_assoc()) {
            $si=$si+1; $id=$row['id'];$n=$row['name'];$c=$row['class'];$r=$row['roll'];
            echo "<tr>";
            echo "<td>$si</td>";
            echo "<td>$n</td>";
            echo "<td>$c</td>";
            echo "<td>$r</td>";
            echo "<td><a href='delete-student.php?id=$id' class='btn btn-danger'>Delete</a></td>";
            echo "</tr>";
          }
        ?>
      </table>
    </div>
  </div>
</div>


<center>
<?php require_once 'inc/footer.php' ?>
</center>


  <!-- js -->
 <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>
</html>
