<?php
require_once 'inc/info.php';
require_once 'inc/db.php';
//require_once 'inc/functions.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/d24c97ff8f.js" crossorigin="anonymous"></script>
    <title><?php echo $title; ?></title>
  </head>
  <body>
<?php require_once 'inc/new-header.php' ?>
<!--slider start-->
<style type="text/css">
  #myslider{
    z-index: 3;
  }
  #fc{background-color: whitesmoke}
</style>
<!--Content start-->

<div id="fc">
<div class="container">
<br><div class="row" >
  <!-- left sidebar-->
  <div class="col-sm-3">
    <div class="card-header bg-secondary text-white">Notice Board</div>
    <div class="card">
      <div class="container"><br>
        <marquee direction='up' scrollamount="2">
        <?php
        $sql = "SELECT * FROM sms_notice ORDER BY id DESC LIMIT 5 ";
        $result = $connect->query($sql);
        while ($row = $result->fetch_assoc()) {
          $id = $row['id'];
          echo "<a href='notice_details.php?id=$id'>".$row['title']."</a><br>";
        }
        ?>
      </marquee>
        <br>
      <a href="notice-view.php" class='btn btn-success'>View All</a>
      </div><br>
    </div>
    <!--attendance start-->
    <div class="card-header text-white bg-secondary">Class Wise Attendance</div>
    <table class='table table-hover table-bordered'>
      <tr>
        <th>Class</th>
        <th>Present</th>
        <th>Absent</th>
        <th>Total</th>
      </tr>
      <tr>
        <td>Six</td>
        <td><span class="badge bg-success rounded-pill">40</span></td>
        <td><span class="badge bg-danger rounded-pill">24</span></td>
        <td><span class="badge bg-info rounded-pill">64</span></td>
      </tr>
      <tr>
        <td>Seven</td>
        <td><span class="badge bg-success rounded-pill">51</span></td>
        <td><span class="badge bg-danger rounded-pill">14</span></td>
        <td><span class="badge bg-info rounded-pill">65</span></td>
      </tr>
      <tr>
        <td>Eight</td>
        <td><span class="badge bg-success rounded-pill">52</span></td>
        <td><span class="badge bg-danger rounded-pill">10</span></td>
        <td><span class="badge bg-info rounded-pill">62</span></td>
      </tr>
      <tr>
        <td>Nine</td>
        <td><span class="badge bg-success rounded-pill">60</span></td>
        <td><span class="badge bg-danger rounded-pill">14</span></td>
        <td><span class="badge bg-info rounded-pill">74</span></td>
      </tr>
      <tr>
        <td>Ten</td>
        <td><span class="badge bg-success rounded-pill">40</span></td>
        <td><span class="badge bg-danger rounded-pill">30</span></td>
        <td><span class="badge bg-info rounded-pill">70</span></td>
      </tr>
    </table>    
    <!-- attendance end-->
  </div>
  
  <div class="col-sm-9">
  <!--slider start-->
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" id="myslider">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="https://unisouthamptonlibrary.files.wordpress.com/2013/10/su-40301.jpg" class="d-block w-100" alt="...">
          <div class="carousel-caption d-none d-md-block">
            <h5>First slide label</h5>
            <p>Some representative placeholder content for the first slide.</p>
          </div>
        </div>
        <div class="carousel-item">
          <img src="http://i.huffpost.com/gen/2755454/images/o-EMPTY-CLASSROOM-facebook.jpg" class="d-block w-100" alt="...">
          <div class="carousel-caption d-none d-md-block">
            <h5>Second slide label</h5>
            <p>Some representative placeholder content for the second slide.</p>
          </div>
        </div>
        <div class="carousel-item">
          <img src="https://www.pittstate.edu/education/_files/images/spedhl-1280x850.jpg" class="d-block w-100" alt="...">
          <div class="carousel-caption d-none d-md-block">
            <h5>Third slide label</h5>
            <p>Some representative placeholder content for the third slide.</p>
          </div>
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"  data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  <!--slider end-->   
  </div>
</div>
</div><!--end container-->
<!--end content-->
</div>
<br>


<!--second section start-->
<div class="container">
  <div class="card mb-3" >
  <div class="row g-0">
    <div class="col-md-4">
      <img src="uploads/kazi.jpg" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Message From Head Master</h5>
        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
    </div>
  </div>
</div>
</div>
<!--second section end-->

<!--history of school start-->
<div class="container">
  <div class="card mb-3">
    <img src="uploads/school.jpeg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">History of The School</h5>
      <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
      consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
      proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div>
  </div>
</div>

<!--end history of school-->

<!-- Gallery Section start-->
<center><h3>Gallery</h3></center><hr>
<div class="p-3 mb-2 bg-secondary text-white">
    <marquee><div class="container">
        <div class='card-group'>
          <?php
          $imgQuery="SELECT * FROM sms_gallery";
          $imgr=$connect->query($imgQuery);
          while($row=$imgr->fetch_assoc()){
              $id=$row['image'];
            echo "<div class='card'>
                    <img src='uploads/$id' class='card-img-top' alt='...'>
                </div>";    
          }
          ?>
   </div></marquee>
</div>
<center><a href='gallery-view.php' class="btn btn-success">View All</a></center>
<br>
<!-- Gallery Section end-->
<!-- section start-->
<center><h3>Our Location</h3></center>
<div class="container">
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d920866.4463128633!2d88.64257460495733!3d25.63365934627396!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fb529bc7fc909b%3A0xd8f861ed9baf24de!2z4Kam4Ka_4Kao4Ka-4Kac4Kaq4KeB4Kaw!5e0!3m2!1sbn!2sbd!4v1696576689690!5m2!1sbn!2sbd" width="100%" height="500px" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
<!-- Section end-->
<!-- section start-->

<!-- section end-->
<!-- section start-->

<!-- section end-->
<?php require_once 'inc/new-footer.php' ?>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
  </body>
</html>