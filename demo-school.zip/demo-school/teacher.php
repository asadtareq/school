<?php
require_once 'inc/session.php';
require_once 'inc/db.php';
//require_once 'inc/user_fetch.php';
require_once 'inc/info.php';
//require_once 'inc/functions.php';

if (isset($_POST['add'])) {
  $not = mysqli_real_escape_string($connect,$_POST['not']);
  $des = mysqli_real_escape_string($connect,$_POST['des']);
  $sub = mysqli_real_escape_string($connect,$_POST['sub']);
  $deg = mysqli_real_escape_string($connect,$_POST['deg']);
  $number = mysqli_real_escape_string($connect,$_POST['number']);
  $doj = mysqli_real_escape_string($connect,$_POST['doj']);
  $image = $_FILES['fileToUpload']['name'];
  $image_tempName=$_FILES['fileToUpload']['tmp_name'];
  $location="uploads/";
  move_uploaded_file($image_tempName,$location."$image");
  $teachersql="INSERT INTO sms_users(`name`,`designation`,`subject`,`degree`,`mobile`,`joining_date`,`image`) VALUES('$not','$des','$sub','$deg','$number','$doj','$image')";
  if ($connect->query($teachersql)) {
    echo "<script>alert('Success')</script>";
    echo "<script>window.location.href = 'teacher.php'</script>";
  }else{
    echo "<script>alert('Failed')</script>";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Basic Page Info -->
  <meta charset="utf-8">
  <title><?php echo $title;?></title>
  <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/d24c97ff8f.js" crossorigin="anonymous"></script>
  

  <!-- Global site tag (gtag.js) - Google Analytics -->
 
 
</head>
<body>
<!--Menu start-->
<?php require('inc/header.php'); ?>       

<div class="container"><br>
  <div class="card-header bg-secondary text-white">Add New Teacher</div>
  <div class="card">
    <div class="container">
      <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label>Name of Teacher</label>
          <input type="text" name="not" class="form-control">
        </div>
        <div class="form-group">
          <label>Designation</label>
          <input type="text" name="des" class="form-control">
        </div><div class="form-group">
          <label>Subject</label>
          <input type="text" name="sub" class="form-control">
        </div><div class="form-group">
          <label>Degree</label>
          <input type="text" name="deg" class="form-control">
        </div>
        <div class="form-group">
          <label>Mobile</label>
          <input type="number" name="number" class="form-control">
        </div>
        <div class="form-group">
          <label>Date of Joining</label>
          <input type="date" name="doj" class="form-control">
        </div>
        <div class="form-group">
          <label>Image</label>
          <input type="file" name="fileToUpload" class="form-control">
        </div>
        <br>
        <input type="submit" name="add" value='Add Teacher' class='btn btn-success'>
      </form><br>
    </div>
  </div>
</div>


<div class="container"><br>
  <div class="card-header bg-secondary text-white">Teachers List</div>
  <div class="card">
    <div class="container">
      <table class='table table-hover table-bordered table-sm'>
        <tr>
          <th>Name</th>
          <th>Subject</th>
          <th>Number</th>
          <th>Action</th>
        </tr>
        <?php
          $sel_te_sql="SELECT * FROM sms_users ";
          $r=$connect->query($sel_te_sql);
          while ($row=$r->fetch_assoc()) {
            $id=$row['id'];$n=$row['name'];$s=$row['subject'];$nm=$row['mobile'];
            echo "<tr>";
            echo "<td>$n</td>";
            echo "<td>$s</td>";
            echo "<td>$nm</td>";
            echo "<td><a href='delete-teacher.php?id=$id' class='btn btn-danger'>Delete</a></td>";
            echo "</tr>";
          }
        ?>
      </table>
    </div>
  </div>
</div>


<center>
<?php require_once 'inc/footer.php' ?>
</center>


  <!-- js -->
  <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>
</html>
