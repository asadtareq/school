<?php
$ip = 'localhost';
$username ='marcwnpw_wp250';
$password = 'afKEFCFW=,Zj';
$dbname = 'marcwnpw_demo';
$connect = new mysqli($ip, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}
?>