<!-- As a link -->
<nav class="navbar navbar-dark bg-success ">
  <div class="container">
  	<div class="container-fluid">
  	<?php
        $sql = "SELECT * FROM sms_notice ORDER BY id DESC LIMIT 1 ";
        $result = $connect->query($sql);
        while ($row = $result->fetch_assoc()) {
          $id = $row['id'];
          $news = "<a id='newsticker' href='notice_details.php?id=$id'>".$row['title']."</a>";
        }
  	?>
    	<div class='row'>
    		<div class='col-2' style="color:white">
    			Latest News:
    		</div>
    		<div class='col-10'>
    			<marquee style="color:white" ><?php echo $news?></marquee>
    		</div>
    	</div>
    
  	</div>
  </div>
</nav>
<!-- Just an image -->
<nav class="navbar navbar-light">
  <div class="container">
    <div class="col-sm-6">
      <a class="navbar-brand" href="#" id='schoolname'>
      <img src="uploads/logo1.jpg" alt="image" width="120" height="120" >
      Raniganj Girl's High School
      </a>
      
    </div>
    <div class="col-sm-6">
      
    </div>
  </div>
</nav>

<nav class="navbar sticky-top  navbar-expand-lg navbar-dark bg-success">
<div class="container">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="teacher-view.php">Teacher</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="smc-view.php">SMC</a>
        </li>
        <!--
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            About
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item " href="history-view.php">History</a></li>
            <li><a class="dropdown-item" href="teacher-view.php">Teacher</a></li>
            <li><a class="dropdown-item" href="">Class Teacher</a></li>
            <li><a class="dropdown-item" href="smc-view.php">SMC</a></li>
          </ul>
        </li>
        -->
        <li class="nav-item ">
          <a class="nav-link active" href="student-view.php">Student</a>
        </li>
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            ECA
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item " href="club-view.php?type=ICT">ICT Club</a></li>
            <li><a class="dropdown-item" href="club-view.php?type=Chess">Chess Club</a></li>
            <li><a class="dropdown-item" href="club-view.php?type=Math">Math Club</a></li>
            <li><a class="dropdown-item" href="club-view.php?type=Language">Language Club</a></li>
            <li><a class="dropdown-item" href="club-view.php?type=Science">Science Club</a></li>
            <li><a class="dropdown-item" href="club-view.php?type=Debate">Debate Club</a></li>
          </ul>
        </li>
        <li class="nav-item ">
          <a class="nav-link active" href="gallery-view.php">Gallery</a>
        </li>
        <li class="nav-item ">
          <a class="nav-link active" href="notice-view.php">Notice</a>
        </li>
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Result
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item " href="http://www.educationboardresults.gov.bd">Board</a></li>
            <li><a class="dropdown-item" href="result-view.php">School</a></li>
          </ul>
        </li>

      </ul>
    </div>
  </div>
</div>
</nav>
<style type="text/css">
  #newsticker{
    text-decoration: none;
    color: white;
  }
  #schoolname{
    font-size: 24px;
  }
</style>