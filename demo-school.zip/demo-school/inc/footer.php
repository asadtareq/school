

<div class="footer-wrap pd-20 mb-20 card-box">
        &copy Developed By <a href="" target="_blank">NanoSoft OPC</a>
      </div>
<style type="text/css">
	#ft{background-color: gray;color: white}
</style>