<?php
function displayID($a){
    if ($a == 'Bangla First') {
     return $display_id = '1'; 
    }elseif($a == 'Bangla Second '){
     return $display_id = '2' ;
    }elseif($a == 'English First'){
     return $display_id = '3';
    }elseif($a == 'English Second'){
     return $display_id = '4';
    }elseif($a == 'Mathematics'){
     return $display_id = '5';
    }elseif($a == 'BGS'){
     return $display_id = '6';
    }elseif($a == 'Religion'){
     return $display_id = '7';
    }elseif($a == 'Science'){
     return $display_id = '8';
    }elseif($a == 'ICT'){
     return $display_id = '9';
    }elseif($a == 'PED'){
     return $display_id = '10';
    }elseif($a == 'VED'){
     return $display_id = '11';
    }elseif($a == 'Arts'){
     return $display_id = '12';
    }elseif($a == 'Career'){
     return $display_id = '13';
    }elseif($a == 'Physics'){
     return $display_id = '14';
    }elseif($a == 'Chemistry'){
     return $display_id = '15';
    }elseif($a == 'Higher Mathematics' || $a == 'Agriculture' || $a == 'Home Science'){
     return $display_id = '16';
    }
}

//gp calculate for general subject
function generalSub($mcq,$cq){
    $GeneralTotal = $cq+$mcq;
    if ($cq<23 || $mcq <10) {
       return "F";
       $generalGP = "F";
    }elseif($GeneralTotal>79){
        return "5";
        $generalGP = 5;
    }elseif($GeneralTotal>69){
        return "4";
        $generalGP = 4;
    }elseif($GeneralTotal>59){
        return "3.5";
        $generalGP = 3.5;
    }elseif($GeneralTotal>49){
        return "3";
        $generalGP = 3;
    }elseif($GeneralTotal>39){
        return "2";
        $generalGP = 2;
    }else{
        return "1";
        $generalGP = 1;
    }
}
//gp calculate for 50 marks subject
function fiftyMark($cq,$mcq){
    $fmTotal = 2*($cq+$mcq);
    if ($fmTotal<17) {
       return $fmGP = "F";
    }elseif($fmTotal>79){
        return $fmGP = 5;
    }elseif($fmTotal>69){
        return $fmGP = 4;
    }elseif($fmTotal>59){
        return $fmGP = 3.5;
    }elseif($fmTotal>49){
        return $fmGP = 3;
    }elseif($fmTotal>39){
        return $fmGP = 2;
    }else{
        return $fmGP = 1;
    }
}


//
function banEng($b_total){
    if($b_total<32){
        $b_gp="F";
        return "F";
    }elseif($b_total>79){
        $b_gp=5;
        return 5;
        
    }elseif($b_total>69){
        $b_gp=4;
        return 4;
        
    }elseif($b_total>59){
        $b_gp=3.5;
        return 3.5;
        
    }elseif($b_total>49){
        $b_gp=3;
        return 3;
        
    }elseif($b_total>39){
        $b_gp=2;
        return 2;
        
    }else{
        $b_gp=1;
        return 1;
        
    }
}

function prac_sub($cq,$mcq,$practical){
    $total = $cq + $mcq + $practical;
    if ($cq<17 || $mcq< 8 || $practical<8) {
     return "F";
    }elseif($total >79 ) {
     $pracGP = 5;
     return 5;
    }elseif($total >69 ) {
     $pracGP = 4;
     return 4;
    }elseif($total >59 ) {
     $pracGP = 3.5;
     return 3.5;
    }elseif($total >49 ) {
     $pracGP = 3;
     return 3;
    }elseif($total >39 ) {
     $pracGP = 2;
     return 2;
    }else{
     $pracGP = 1;
     return 1;
    }
}



function sscgpa($b_gp,$eng_gp,$math_gp,$scienceGp,$religion_gp,$ict_gp,$career_gp,$ped_gp,$sub1,$sub2,$sub3,$fourthSubjectGP){
    if ($b_gp == "F" || $eng_gp == "F" || $math_gp == "F" || $scienceGp == "F" || $religion_gp == "F" || $ict_gp == "F" || $career_gp == "F" || $ped_gp == "F" || $sub1 == "F" || $sub2 == "F" || $sub3 == "F") {
        return "Fail";
    }else{
        $sscgpa=($b_gp + $eng_gp + $math_gp + $scienceGp + $religion_gp + $ict_gp + $career_gp + $ped_gp + $sub1 + $sub2 + $sub3 + $fourthSubjectGP)/11;
        return round($sscgpa,2);
    }
}


function gpa($b_gp,$eng_gp,$math_gp,$bgs_gp,$sci_gp,$religion_gp,$ict_gp,$agri_gp,$ved_gp,$ped_gp,$art_gp){
 if ($b_gp == "F" || $eng_gp == "F" || $math_gp == "F" || $bgs_gp == "F" || $sci_gp == "F" || $ict_gp == "F" || $religion_gp == "F" || $agri_gp == "F" || $ved_gp == "F" || $ped_gp == "F" || $art_gp == "F") {
     return "Fail";
 }else{
     $gpa=($b_gp+$eng_gp+$math_gp+$bgs_gp+$sci_gp+$religion_gp+$ict_gp+$agri_gp + $ved_gp+$ped_gp+$art_gp)/11;
     return round($gpa,2);
 }
}


?>

