<?php
require_once 'inc/session.php';
?>

<center><h1>Raniganj Girl's High School </h1></center>
<hr>
<marquee><h1>Welcome <?php echo $login_name?></h1></marquee>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="teacher.php">Teacher</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='smc.php'>SMC</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='student.php'>Student</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='notice.php'>Notice</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='gallery.php'>Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='club.php'>Club</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='profile.php'>Profile</a>
        </li>
        <li class="nav-item">
          <a class="btn btn-danger" href='logout.php'>Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<style type="text/css">
	body{
		background-color:whitesmoke;
	}
</style>