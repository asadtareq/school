<?php
require_once 'functions.php';
$mobile=$_SESSION['login_user'];
$connection_read = mysqli_connect($ip, $username, $password, $dbname);
$query = "SELECT * FROM sms_login  WHERE `mobile` = '$mobile' ";
$result = $connect->query($query);
  while ($row = $result->fetch_assoc()) {
  	$user_id = $row['uid']; 
    $user_name=$row['name'];
    $user_password = $row['pass'];
    $user_role = $row['role'];
  }
$sql = "SELECT * FROM sms_users  WHERE `id` = '$user_id' ";
$result = $connect->query($sql);
  while ($row = $result->fetch_assoc()) {
  	$id = $row['id']; 
  //	$user_name=$row['name'];
   // $user_section = $row['section'];
    $joining_date = $row['joining_date'];
    $designation = $row['designation'];

  }
// class teacher section fetch 
$ctsql = "SELECT * FROM sms_ct_info  WHERE `tid` = '$user_id' ";
$result = $connect->query($ctsql);
  while ($row = $result->fetch_assoc()) { 
    $ct_section = $row['section'];

  }
?>


