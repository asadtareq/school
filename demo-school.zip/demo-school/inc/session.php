<?php
session_start();
require('db.php');
$user_check = $_SESSION['login_user'];
$connection = mysqli_connect($ip, $username, $password, $dbname);
$ses_sql = mysqli_query($connection,"SELECT * FROM sms_login WHERE `mobile` = '{$user_check}' ");
$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
$login_session = $row['mobile'];
$login_name = $row['name'];
$login_pass = $row['pass'];
if(!isset($_SESSION['login_user'])){
 // header("location:index.php");
  echo "<script>window.location.href = 'index.php'</script>";
}

?>
