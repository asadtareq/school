<?php
$fav="<link rel='shortcut icon' type='image/png' href='inc/favicon.png'/>";
$title = "Raniganj Girl's High School";
$app_name = "Raniganj Girl's High School";
$app_address = "<center>Post: HatShampur-5200, Upozilla: Ghoraghat, District: Dinajpur <br><br></center>";
?>
