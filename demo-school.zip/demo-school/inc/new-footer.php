<div class="card" style="background-color:black;color:white">
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <div>
         <br>Contacts<br>
         Phone - 0531-00000<br>
         Email - ranigonjgirlshighschool@gmail.com, 
         Fax - 0531-000<br>
         Address - Post: HatShampur-5200, Upozilla: Ghoraghat, District: Dinajpur
        </div>
      </div>
      <div class="col-sm-4">
        <div id="iml" >
          <br>Important Links<br>
          <a href="" >Dinajpur Board</a><br>
          <a href="">Ministry of Education</a><br>
          <a href="">DSHE</a><br>
          <a href="">BANBEISE</a><br>
          <a href="">DEO</a>
        </div>
      </div>
      <div class="col-sm-4">
        <div>
        <br>Social Media<br>
          <ul id='social'>
            <li><a href='https://www.facebook.com'>Facebook</a></li>
            <li><a href='https://www.youtube.com'>Youtube</a></li>
            <li><a href='https://www.twitter.com'>Twitter</a></li>
            <li><a href='https://www.linkedin.com'>Linkedin</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div><br><hr>
  <center><?php echo date('Y'); ?> &copy  &nbsp Design & Developed By NanoSoft</center>
</div>
<style type="text/css">
  #iml a{color:white;}
  #social li a{
    text-decoration:none;color: white;
  }
</style>