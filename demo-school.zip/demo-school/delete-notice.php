<?php
require_once 'inc/session.php';
require_once 'inc/db.php';
require_once 'inc/user_fetch.php';
require_once 'inc/info.php';
require_once 'inc/functions.php';

$id = $_GET['id'];
  $del_no="DELETE FROM sms_notice WHERE id = '$id' ";
  if ($connect->query($del_no)) {
    echo "<script>alert('Success')</script>";
    echo "<script>window.location.href = 'notice.php'</script>";
  }else{
    echo "<script>alert('Failed')</script>";
  }
?>


  <!-- js -->
  <script src="vendors/scripts/core.js"></script>
  <script src="vendors/scripts/script.min.js"></script>
  <script src="vendors/scripts/process.js"></script>
  <script src="vendors/scripts/layout-settings.js"></script>
  <script src="src/plugins/apexcharts/apexcharts.min.js"></script>
  <script src="src/plugins/datatables/js/jquery.dataTables.min.js"></script>
  <script src="src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
  <script src="src/plugins/datatables/js/dataTables.responsive.min.js"></script>
  <script src="src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
  <script src="vendors/scripts/dashboard.js"></script>
</body>
</html>
