<?php
require_once 'inc/session.php';
require_once 'inc/db.php';
//require_once 'inc/user_fetch.php';
require_once 'inc/info.php';
//require_once 'inc/functions.php';
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Basic Page Info -->
  <meta charset="utf-8">
  <title><?php echo $title;?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/d24c97ff8f.js" crossorigin="anonymous"></script>
 
</head>
<body>
<!--Menu start-->
<?php require('inc/header.php'); ?>
<?php
// $current_year = date('Y');$current_date = date('d-m-Y'); 
// $sql = "SELECT * FROM sms_student_info WHERE year='$current_year' ";
// $result = $connect->query($sql);
// $totalStudent = mysqli_num_rows($result);


?>       

<div class='container'>
    <div class='card'>
        <div class='container'>
            <center><h1>Admin Dashboard</h1></center>
        </div>
    </div>
</div>

<div class='container'>
    <?php require_once 'inc/footer.php' ?>
</div>

  <!-- js -->
  <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    -->
</body>
</html>
